In diesem Verzeichnis können GIF-Dateien platziert werden, die der Bot als Antwort senden wird.
Zum Beispiel: parrot1.gif, parrot2.gif, usw.
